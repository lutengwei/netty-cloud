package com.yb.moudle;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableFill;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.*;

/**
 * Hello world!
 *
 */
public class SystemModule {

    private static String authorName = System.getenv().get("USERNAME");
    private static String[] prefix = new String[] { "" };
    private static Map<String, String> map = null;


    /**
     * 代码生成
     */
    public static void main(String[] args) {

        String configPath = System.getProperty("user.dir");
        try {
            map = readXMLToMap(new File(configPath + "/config.xml"));
        } catch (DocumentException e) {
            System.out.println("读取xml配置文件失败");
            e.printStackTrace();
        }
        String table = map.get("table");
        String[] tables = table.split(",");
        // 自定义需要填充的字段
        List<TableFill> tableFillList = new ArrayList<>();
        // tableFillList.add(new TableFill("ASDD_SS", FieldFill.INSERT_UPDATE));
        // 代码生成器
        AutoGenerator mpg = new AutoGenerator().setGlobalConfig(
                // 全局配置
                new GlobalConfig().setOutputDir(map.get("path") + "/src/main/java")// 输出目录
                        .setFileOverride(true)// 是否覆盖文件
                        .setActiveRecord(true)// 开启 activeRecord 模式
                        .setEnableCache(false)// XML 二级缓存
                        .setBaseResultMap(true)// XML ResultMap
                        .setBaseColumnList(true)// XML columList
                        .setOpen(false)// 生成后打开文件夹
                        .setAuthor(authorName)
                        // 自定义文件命名，注意 %s 会自动填充表实体属性！
                        .setMapperName("%sMapper").setXmlName("%sMapper").setServiceName("%sService").setServiceImplName("%sServiceImpl")
                        .setControllerName("%sController"))
                .setDataSource(
                        // 数据源配置
                        new DataSourceConfig().setDbType(DbType.MYSQL)// 数据库类型
                                .setDriverName(map.get("driverName")).setUsername(map.get("username")).setPassword(map.get("password")).setUrl(map.get("url"))
//                        new DataSourceConfig().setDbType(DbType.SQL_SERVER)// 数据库类型
//                                .setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver").setUsername("sa").setPassword("U8_sql2016ver.")
//                                .setUrl("jdbc:sqlserver://47.99.137.141;DatabaseName=cstar_voucher_middle_db")

                ).setStrategy(
                        // 策略配置
                        new StrategyConfig().setTablePrefix(prefix)// 此处可以修改为您的表前缀
                                .setNaming(NamingStrategy.underline_to_camel)// 表名生成策略
                                .setInclude(tables) // 需要生成的表
                                .setRestControllerStyle(true).setTableFillList(tableFillList).setEntityLombokModel(true))
                .setPackageInfo(
                        // 包配置
                        new PackageConfig().setParent("com." + map.get("projectName") + "." + map.get("packageClass"))// 自定义包路径
                                .setController("controller")// 这里是控制器包名，默认 web
                                .setEntity("entity").setMapper("mapper").setService("service").setServiceImpl("service.impl")
                        // .setXml("mapper")
                ).setCfg(
                        // 注入自定义配置，可以在 VM 中使用 cfg.abc 设置的值
                        new InjectionConfig()
                        {

                            @Override
                            public void initMap() {
                                Map<String, Object> map = new HashMap<>();
                                // map.put("abc",
                                // this.getConfig().getGlobalConfig().getAuthor()
                                // + "-mp");
                                this.setMap(map);
                            }
                        }.setFileOutConfigList(Collections.singletonList(new FileOutConfig("/templates/mapper.xml.vm")
                        {

                            // 自定义输出文件目录
                            @Override
                            public String outputFile(TableInfo tableInfo) {
                                return map.get("path") + "/src/main/resources/mapper/" + map.get("packageClass") + "/" + tableInfo.getEntityName() + "Mapper.xml";
                            }
                        })))
                .setTemplate(
                        // 关闭默认 xml 生成，调整生成 至 根目录
                        new TemplateConfig().setXml(null)
                                // 自定义模板配置，模板可以参考源码
                                // /mybatis-plus/src/main/resources/template 使用
                                // copy
                                // 至您项目 src/main/resources/template
                                // 目录下，模板名称也可自定义如下配置：
                                .setController("").setEntity("").setMapper("").setXml("").setService("").setServiceImpl("")
                                .setController("/template/controller.java.vm")
                                .setEntity("/template/entity.java.vm")
                                .setMapper("/template/mapper.java.vm").setService("/template/service.java.vm")
                                .setServiceImpl("/template/serviceImpl.java.vm")
                );
        // 执行生成
        mpg.execute();
        // 打印注入设置，这里演示模板里面怎么获取注入内容【可无】
        //System.err.println(mpg.getCfg().getMap().get("abc"));
        System.out.println("代码生成成功！");

    }

    /**
     * xml转map
     * @param file
     * @return
     * @throws DocumentException
     */
    public static Map<String,String> readXMLToMap(File file) throws DocumentException {
        //1.创建Reader对象
        SAXReader reader = new SAXReader();
        //2.加载xml
        Document document = reader.read(file);
        //3.获取根节点
        Element rootElement = document.getRootElement();
        Iterator iterator = rootElement.elementIterator();
        Map<String, String> hashMap = new HashMap<>();
        while (iterator.hasNext()){
            Element stu = (Element) iterator.next();
            List<Attribute> attributes = stu.attributes();
            for (Attribute attribute : attributes) {
                System.out.println(attribute.getValue());
            }
            Iterator iterator1 = stu.elementIterator();
            while (iterator1.hasNext()){
                Element stuChild = (Element) iterator1.next();
                hashMap.put(stuChild.getName(),stuChild.getStringValue());
            }
        }
        return hashMap;
    }
}